package itunes_analyzer;

public class ITunesSettings {

	public static String SQL_USERNAME = "root";

	public static String SQL_PASSWORD = "Futbolpal@87";

	public static String SQL_LOCATION = "5.127.217.36";


}
