package file_analyzer;

import java.util.ArrayList;

public class FileAnalyzerSettings {

	public static String ROOT = "/media/BACKUP/My Documents/My Music";
	public static ArrayList<String> FORMATS = new ArrayList<String>();
}
